part1.c is the source code for part1 of the exercise

part1-part5 are sample solutions. These are executable files that can be run on the 
DE1-SoC board. The part3 and part4 programs exit after 12 seconds, and part5 after 60 seconds.

part5 requires the drivers /dev/IntelFPGAUP/KEY and /dev/IntelFPGAUP/SW. These drivers 
can be found in the folder /home/root/Linux_Libraries/drivers.
