The file part1 is an ARM executable program that provides a sample solution to Part 1. The files
physical.c and physical.h provide source code that can be used to map physical addresses to
virtual addresses.
