The file part3 is an ARM executable program that provides a sample solution to Part 3. The files
physical.c and physical.h provide source code that can be used to map physical addresses to
virtual addresses.

The program takes an optional arguments
   [keyboard-path] provides a path to the keyboard device. Example:
	   /dev/input/by-id/usb-Logitech_USB_Receiver-event-kbd
