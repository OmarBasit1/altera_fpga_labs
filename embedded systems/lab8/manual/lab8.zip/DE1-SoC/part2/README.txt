The file part2 is an ARM executable program that provides a sample solution to Part 2. The files
physical.c and physical.h provide source code that can be used to map physical addresses to
virtual addresses.
