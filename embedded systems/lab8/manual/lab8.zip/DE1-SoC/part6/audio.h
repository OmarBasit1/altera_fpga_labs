#ifndef AUDIO_H_
#define AUDIO_H_

#define PI 3.14159265
#define PI2 6.28318531
#define SAMPLING_RATE 8000

#endif /*AUDIO_H_*/
