The file part3 is an executable program. It is an example solution to Part 3.  The piano tones
are played on the audio device of the DE10-Nano board, and (if the optional -w argument is given)
are also written to the file piano.wav. This is an MS Windows audio file.

The files wav.c and wav.h can be used in any program to create a WAV file.
