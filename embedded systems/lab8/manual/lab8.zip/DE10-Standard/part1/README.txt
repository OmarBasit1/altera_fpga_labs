The file part1 is an executable program. It is an example solution to Part 1.  The chromatic 
scale is played on the audio device of the DE10-Standard board, and is also written (if the 
optional -w argument is given) to the file piano.wav. This is an MS Windows audio file.

The files wav.c and wav.h can be used in any program to create a WAV file.
