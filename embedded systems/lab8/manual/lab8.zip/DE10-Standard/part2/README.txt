The file part2 is an executable program. It is an example solution to Part 2. The selected chord
is played on the audio device of the DE10-Standard board, and (if the optional -w argument is 
given) is also written to the file piano.wav. This is an MS Windows audio file.

The files wav.c and wav.h can be used in any program to create a WAV file.
