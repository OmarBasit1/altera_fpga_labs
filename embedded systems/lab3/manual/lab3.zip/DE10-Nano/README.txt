Part4 is an executable file and example solution to Part IV. It requires the drivers 
/dev/IntelFPGAUP/SW, dev/IntelFPGAUP/KEY, and /dev/IntelFPGAUP/LED.
These drivers can be found in /home/root/Linux_Libraries/drivers.

In the part4 program, whenever a pushbutton KEY is pressed the SW switches are copied to the
LED lights.

The program automatically exits after 12 seconds.
